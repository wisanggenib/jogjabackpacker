<?php
include 'template/header.php';
?>

    <section class="site-hero overlay page-inside" style="background-image: url(img/hero_2.jpg)">
      <div class="container">
        <div class="row site-hero-inner justify-content-center align-items-center">
          <div class="col-md-10 text-center">
            <h1 class="heading" data-aos="fade-up">Selamat Datang <br> Saudara Satria</h1>
            <p class="sub-heading mb-5" data-aos="fade-up" data-aos-delay="100">Nikmati liburan anda.</p>
          </div>
        </div>
        <!-- <a href="#" class="scroll-down">Scroll Down</a> -->
      </div>
    </section>
    <!-- END section -->
    <section class="section bg-pattern">
            <div class="container">
              <div class="row">
                <div class="col-md-6">
                  
                        <h3>Detail Pesanan</h3>
                        <form style="color: black">
                              <div class="form-group">
                                <label for="exampleFormControlInput1">Kode Pemesanan</label>
                                <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                              </div>
              
                              <div class="form-group">
                                      <label for="exampleFormControlInput1">Nama Pemesan</label>
                                      <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                                    </div>
              
                                    <div class="form-group">
                                          <label for="exampleFormControlInput1">Tanggal Berangkat</label>
                                          <input type="date" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                                        </div>
                                        <div class="form-group">
                                              <label for="exampleFormControlInput1">Tanggal Pulang</label>
                                              <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                                            </div>
                                    <div class="form-group">
                                          <label for="exampleFormControlInput1">Total</label>
                                          <input type="number" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                                        </div>
              
                              <div class="form-group">
                                <label for="exampleFormControlTextarea1">Keterangan</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                              </div>
                            </form>
      
                </div>
                <div class="col-md-5">
                        <h3>List Peserta</h3>
                        <table class="table table-bordered ">
                                <thead class="thead-dark">
                                  <a href="">
                                    <tr>
                                      <th scope="col">NIP</th>
                                      <th scope="col">Nama</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <th scope="row">900145465</th>
                                    <td>Karina Jenia Felishanty</td>
                                  </tr>
                                  <tr>
                                    <th scope="row">902564123</th>
                                    <td>Bagus Wisanggeni</td>
                                  </tr>
                                </tbody>
                              </table>
                </div>
              </div>
            </div>
          </section>
          
          <?php
          include 'template/footer.php';
          ?>