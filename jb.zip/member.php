<?php
include 'template/header.php';
?>

  <section class="site-hero overlay page-inside" style="background-image: url(img/hero_2.jpg)">
    <div class="container">
      <div class="row site-hero-inner justify-content-center align-items-center">
        <div class="col-md-10 text-center">
          <h1 class="heading" data-aos="fade-up">Selamat Datang <br> Saudara Satria</h1>
          <p class="sub-heading mb-5" data-aos="fade-up" data-aos-delay="100">Nikmati liburan anda.</p>
        </div>
      </div>
      <!-- <a href="#" class="scroll-down">Scroll Down</a> -->
    </div>
  </section>
  <!-- END section -->


  <!-- END section -->

  <section class="section slider-section bg-pattern">
    <div class="container">
      <div class="row justify-content-center text-center mb-5">
        <div class="col-md-8">
          <h2 class="heading" data-aos="fade-up">Pesanan Aktif</h2>
          <br>
          <table class="table table-bordered " data-aos="fade-up">
            <thead class="thead-dark">
              <a href="">
                <tr>
                  <th scope="col">Kode</th>
                  <th scope="col">Nama Paket</th>
                  <th scope="col">Tanggal</th>
                  <th scope="col">Status</th>
                  <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">B001</th>
                <td>Yogyakarta Happy Hours</td>
                <td>03-Mei-2019</td>
                <td class="table-warning">Belum Bayar</td>
                <td> <a href="detail.php"> <button type="button" class="btn2 btn-info">Detail paket</button> </a></td>
              </tr>
              <tr>
                <th scope="row">B002</th>
                <td>Pantai Parang Tritis</td>
                <td>03-Mei-2019</td>
                <td class="table-success">Sudah</td>
                <td><button type="button" class="btn2 btn-info">Detail paket</button></td>
              </tr>
            </tbody>
          </table>

        </div>
      </div>
    </div>
  </section>

  <?php
  include 'template/footer.php';
  ?>