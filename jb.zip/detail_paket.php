<?php
include 'template/header.php';
?>

<section class="site-hero overlay page-inside" style="background-image: url(img/hero_2.jpg)">
  <div class="container">
    <div class="row site-hero-inner justify-content-center align-items-center">
      <div class="col-md-10 text-center">
        <h1 class="heading" data-aos="fade-up">Selamat Datang <br> Saudara Satria</h1>
        <p class="sub-heading mb-5" data-aos="fade-up" data-aos-delay="100">Nikmati liburan anda.</p>
      </div>
    </div>
    <!-- <a href="#" class="scroll-down">Scroll Down</a> -->
  </div>
</section>
<!-- END section -->


<!-- END section -->

<section class="section slider-section bg-pattern">
  <div class="container">
    <div class="row mb-5">
      <div class="col-md-8">
        <h2 class="" data-aos="fade-up" align="left">5 Day Trip Backpacker</h2>
      </div>
    </div>
    <div class="row mb-5">
      <div class="col-md-6" align="center">
       <img src="img/hero_2.jpg" class="img-responsive" width="500px">
     </div>
     <div class="col-md-6">
      <!-- Nav tabs -->
      <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" data-toggle="tab" href="#destinas">Destinasi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#detail">Detail</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#pesan">Pesan</a>
        </li>
      </ul>

      <!-- Tab panes -->
      <div class="tab-content" style="">
        <div id="destinas" class="container tab-pane active"><br>
          <p>
            <ul>
              <li>a</li>
              <li>a</li>
              <li>a</li>
              <li>a</li>
              <li>a</li>
              <li>a</li>
              <li>a</li>
              <li>a</li>
            </ul>
          </p>
        </div>
        <div id="detail" class="container tab-pane fade"><br>
          <h3>Harga</h3>
          <p>Rp. 750.000</p>
          <h3>Detail</h3>
          <p>Sudah Termasuk : transportasi, parkir, antar-jemput bandara atau stasiun, ?driver, bensin, hotel, tiket masuk wisata, pemandu lokal, air mineral dan snack selama perjalanan.???.</p>
        </div>
        <div id="pesan" class="container tab-pane fade"><br>
          <h3>List Peserta</h3>
          <p>
            <form action="#" method="post">
              <div class="row">
                <div class="col-md-6 form-group">
                  <label for="name">Anggota 1</label>
                  <input type="text" id="name" class="form-control ">
                </div>
                <div class="col-md-6 form-group">
                  <label for="phone">Anggota 2</label>
                  <input type="text" id="phone" class="form-control ">
                </div>
                <div class="col-md-6 form-group">
                  <label for="name">Anggota 3</label>
                  <input type="text" id="name" class="form-control ">
                </div>
                <div class="col-md-6 form-group">
                  <label for="name">Anggota 4</label>
                  <input type="text" id="name" class="form-control ">
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 form-group" align="center">
                  <input type="submit" value="Send Message" class="btn btn-primary">
                </div>
              </div>
            </form>
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<?php
include 'template/footer.php';
?>